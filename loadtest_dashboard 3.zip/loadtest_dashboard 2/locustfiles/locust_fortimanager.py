from locust import HttpUser, task, between

class FortiUser(HttpUser):
    wait_time = between(1, 2)

    @task
    def create_policy(self):
        self.client.get("/")