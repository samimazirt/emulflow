import asyncio
import subprocess
import signal
import os
import re
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
import threading
import requests
from pydantic import BaseModel
import httpx

app = FastAPI()
app.mount("/static", StaticFiles(directory="frontend", html=True), name="static")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

processes = {}
log_clients = {}
log_queues = {}
stop_events = {}  # Nouvel événement pour notifier la fin du test

locust_configs = {
    "fortimanager": {
        "port": 8081,
        "file": "locustfiles/locust_fortimanager.py",
        "host": "http://localhost:8001"
    },
    "paloalto": {
        "port": 8082,
        "file": "locustfiles/locust_paloalto.py",
        "host": "http://localhost:8002"
    }
}

class LaunchRequest(BaseModel):
    appliance: str
    users: int
    rate: int
    duration: int  # en secondes

async def schedule_stop(appliance: str, duration: int):
    print(f"⏳ Test '{appliance}' s'arrêtera automatiquement dans {duration} secondes.")
    await asyncio.sleep(duration)
    await stop_test(appliance)
    print(f"✅ Test '{appliance}' arrêté automatiquement après {duration} secondes.")

    # Notifier la fin du test
    if appliance in stop_events:
        stop_events[appliance].set()

@app.post("/start")
async def start_test(req: LaunchRequest):
    appliance = req.appliance
    if appliance not in locust_configs:
        return {"status": "error", "error": "Appliance inconnue"}

    port = locust_configs[appliance]["port"]
    locustfile = locust_configs[appliance]["file"]
    host = locust_configs[appliance]["host"]

    await stop_test(appliance)

    output_dir = f"results/{appliance}"
    os.makedirs(output_dir, exist_ok=True)

    cmd = [
        "locust", "-f", locustfile,
        "--host", host,
        "--html", f"{output_dir}/report.html",
        "--csv", f"{output_dir}/report",
        "--web-port", str(port)
        # pas de --headless, pas de --run-time
    ]

    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    processes[appliance] = p

    # Créer un nouvel event asyncio pour la fin du test
    stop_events[appliance] = asyncio.Event()

    await asyncio.sleep(5)  # attendre que le Web UI soit prêt

    async with httpx.AsyncClient() as client:
        try:
            r = await client.post(f"http://localhost:{port}/swarm", data={
                "user_count": req.users,
                "spawn_rate": req.rate
            })
            r.raise_for_status()
            print("✅ POST /swarm:", r.status_code, r.text)
        except Exception as e:
            return {"status": "failed to start swarm", "error": str(e)}

    asyncio.create_task(schedule_stop(appliance, req.duration))
    await start_log_forwarding(appliance, p)

    return {"status": "started"}

async def start_log_forwarding(appliance: str, process: subprocess.Popen):
    queue = asyncio.Queue()
    log_queues[appliance] = queue

    loop = asyncio.get_running_loop()

    def enqueue_output():
        for line in iter(process.stdout.readline, ''):
            if line:
                asyncio.run_coroutine_threadsafe(queue.put(line.strip()), loop)
            else:
                break

    threading.Thread(target=enqueue_output, daemon=True).start()

    async def sender():
        while True:
            line = await queue.get()
            ws = log_clients.get(appliance)
            if ws:
                try:
                    await ws.send_text(line)
                except Exception:
                    pass

    asyncio.create_task(sender())

@app.post("/stop/{appliance}")
async def stop_test(appliance: str):
    p = processes.get(appliance)
    if p:
        p.send_signal(signal.SIGINT)
        p.wait()
        del processes[appliance]
    # notifier la fin du test si nécessaire
    if appliance in stop_events:
        stop_events[appliance].set()
    return {"status": "stopped"}

@app.websocket("/ws/logs/{appliance}")
async def log_ws(websocket: WebSocket, appliance: str):
    await websocket.accept()
    log_clients[appliance] = websocket
    try:
        while True:
            await asyncio.sleep(1)
    except WebSocketDisconnect:
        if appliance in log_clients:
            del log_clients[appliance]

@app.websocket("/ws/stats/{appliance}")
async def stats_ws(websocket: WebSocket, appliance: str):
    await websocket.accept()
    port = locust_configs[appliance]["port"]

    # On attend l'event stop, s'il n'existe pas on crée
    if appliance not in stop_events:
        stop_events[appliance] = asyncio.Event()

    try:
        while True:
            try:
                r = requests.get(f"http://localhost:{port}/stats/requests")
                r.raise_for_status()
                data = r.json()

                total_stats = next((s for s in data.get("stats", []) if s.get("name") == "Aggregated"), None)
                users = data.get("user_count", 0)

                if total_stats:
                    response = {
                        "users": users,
                        "rps": total_stats.get("current_rps", 0),
                        "avg_response_time": total_stats.get("avg_response_time", 0),
                        "failures": total_stats.get("current_fail_per_sec", 0),
                        "running": True
                    }
                else:
                    response = {"users": 0, "rps": 0, "avg_response_time": 0, "failures": 0, "running": True}

                await websocket.send_json(response)
            except Exception:
                await websocket.send_json({"users": 0, "rps": 0, "avg_response_time": 0, "failures": 0, "running": True})

            # Quitter la boucle si le test est arrêté (event set)
            if stop_events[appliance].is_set():
                await websocket.send_json({"running": False})
                break

            await asyncio.sleep(2)
    except WebSocketDisconnect:
        pass
    finally:
        if appliance in stop_events:
            stop_events[appliance].clear()

@app.get("/download/{appliance}/report")
def download_report(appliance: str):
    file_path = f"results/{appliance}/report.html"
    return FileResponse(file_path, filename=f"{appliance}_report.html")
