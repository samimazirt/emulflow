// tailwind.config.js
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}", "./public/index.html"],
  theme: {
    extend: {},
  },
  plugins: [require("daisyui")],  // <-- ici on met le plugin daisyui comme avant
  daisyui: {
    themes: ["light"], // ou "dark" ou "cupcake" etc.
  },
};
