import React, { useState, useEffect, useRef } from "react";
import Chart from "chart.js/auto";

function SingleChart({ label, borderColor, data, labels }) {
  const canvasRef = useRef(null);
  const chartInstance = useRef(null);

  useEffect(() => {
    if (chartInstance.current) chartInstance.current.destroy();

    chartInstance.current = new Chart(canvasRef.current, {
      type: "line",
      data: {
        labels,
        datasets: [
          {
            label,
            data,
            borderColor,
            backgroundColor: `${borderColor}33`,
            borderWidth: 2,
            fill: false,
            tension: 0.3,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        animation: false,
        scales: {
          y: { beginAtZero: true },
        },
        plugins: {
          legend: {
            labels: {
              color: "#a3a3a3",
              font: { weight: "bold" },
            },
          },
        },
      },
    });

    return () => chartInstance.current?.destroy();
  }, [label, borderColor, data, labels]);

  return (
    <div className="h-64">
      <canvas ref={canvasRef} />
    </div>
  );
}



function ApplianceTest({ name, displayName }) {
  const [open, setOpen] = useState(false);
  const [users, setUsers] = useState(10);
  const [rate, setRate] = useState(1);
  const [duration, setDuration] = useState(60);

  const [logs, setLogs] = useState([]);
  const [labels, setLabels] = useState([]);
  const [usersData, setUsersData] = useState([]);
  const [rpsData, setRpsData] = useState([]);
  const [timeData, setTimeData] = useState([]);
  const [failuresData, setFailuresData] = useState([]);

  const logSocket = useRef(null);
  const statsSocket = useRef(null);
  const [running, setRunning] = useState(false);

  useEffect(() => {
    if (!running) {
      logSocket.current?.close();
      statsSocket.current?.close();
    }
  }, [running]);

  const reset = () => {
    setLogs([]);
    setLabels([]);
    setUsersData([]);
    setRpsData([]);
    setTimeData([]);
    setFailuresData([]);
  };

  const startTest = async () => {
    reset();

    logSocket.current?.close();
    statsSocket.current?.close();

    try {
      await fetch("http://localhost:8000/start", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ appliance: name, users, rate, duration }),
      });

      logSocket.current = new WebSocket(`ws://localhost:8000/ws/logs/${name}`);
      statsSocket.current = new WebSocket(`ws://localhost:8000/ws/stats/${name}`);

      logSocket.current.onmessage = (e) =>
        setLogs((prev) => [...prev.slice(-99), e.data]);

      statsSocket.current.onmessage = (e) => {
        try {
          const data = JSON.parse(e.data);
          const { users, rps, avg_response_time, failures, finished } = data;
          const time = new Date().toLocaleTimeString();

          setLabels((prev) => [...prev, time].slice(-20));
          setUsersData((prev) => [...prev, users].slice(-20));
          setRpsData((prev) => [...prev, rps].slice(-20));
          setTimeData((prev) => [...prev, avg_response_time].slice(-20));
          setFailuresData((prev) => [...prev, failures].slice(-20));

          if (finished) {
            setRunning(false);
          }
        } catch (err) {
          console.error("Erreur de parsing stats :", err);
        }
      };

      logSocket.current.onclose = () => {
        console.log("log socket closed");
        setRunning(false);
      };

      statsSocket.current.onclose = () => {
        console.log("stats socket closed");
        setRunning(false);
      };

      setRunning(true);
    } catch (err) {
      console.error("Erreur lors du démarrage :", err);
      alert("Erreur lors du démarrage du test");
    }
  };

  const stopTest = async () => {
    await fetch(`http://localhost:8000/stop/${name}`, { method: "POST" });
    setRunning(false);
  };

  const downloadReport = () => {
    window.open(`http://localhost:8000/download/${name}/report`, "_blank");
  };

  return (
    <div className="card bg-base-100 shadow-md p-4 mb-6">
      <button
        className="btn btn-ghost w-full text-left"
        onClick={() => setOpen((o) => !o)}
      >
        <h3 className="text-xl font-semibold">{displayName}</h3>
      </button>

      {open && (
        <div className="mt-4 space-y-4">
          {/* Inputs */}
          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="label">
                <span className="label-text">Utilisateurs</span>
              </label>
              <input
                type="number"
                className="input input-bordered w-full"
                value={users}
                onChange={(e) => setUsers(Number(e.target.value))}
                disabled={running}
                min={1}
              />
            </div>

            <div>
              <label className="label">
                <span className="label-text">Taux (r/s)</span>
              </label>
              <input
                type="number"
                className="input input-bordered w-full"
                value={rate}
                onChange={(e) => setRate(Number(e.target.value))}
                disabled={running}
                min={1}
              />
            </div>

            <div>
              <label className="label">
                <span className="label-text">Durée (sec)</span>
              </label>
              <input
                type="number"
                className="input input-bordered w-full"
                value={duration}
                onChange={(e) => setDuration(Number(e.target.value))}
                disabled={running}
                min={1}
              />
            </div>
          </div>

          {/* Boutons */}
          <div className="flex flex-wrap gap-4">
            <button
              className="btn btn-primary"
              onClick={startTest}
              disabled={running}
            >
              Lancer
            </button>
            <button
              className="btn btn-error"
              onClick={stopTest}
              disabled={!running}
            >
              Arrêter
            </button>
            <button
              className="btn btn-accent"
              onClick={downloadReport}
              disabled={running}
            >
              Télécharger le rapport
            </button>
            <button
              className="btn btn-outline"
              onClick={reset}
              disabled={running}
            >
              Réinitialiser
            </button>
          </div>

          {/* Logs */}
          <div className="mt-4">
            <h4 className="font-semibold mb-1">Logs</h4>
            <div className="bg-base-300 rounded p-3 h-40 overflow-y-auto text-sm font-mono whitespace-pre-wrap">
              {logs.map((log, i) => (
                <div key={i}>{log}</div>
              ))}
            </div>
          </div>

          {/* Charts */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
            <div className="card bg-base-100 shadow-md p-4">
              <SingleChart
                label="Utilisateurs actifs"
                borderColor="#3b82f6"
                data={usersData}
                labels={labels}
              />
            </div>
            <div className="card bg-base-100 shadow-md p-4">
              <SingleChart
                label="RPS"
                borderColor="#ef4444"
                data={rpsData}
                labels={labels}
              />
            </div>
            <div className="card bg-base-100 shadow-md p-4">
              <SingleChart
                label="Temps de réponse"
                borderColor="#10b981"
                data={timeData}
                labels={labels}
              />
            </div>
            <div className="card bg-base-100 shadow-md p-4">
              <SingleChart
                label="Échecs/s"
                borderColor="#f59e0b"
                data={failuresData}
                labels={labels}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}



// Composant principal qui liste les appliances et rend un ApplianceTest par appliance
export default function App() {
  const appliances = [
    { name: "fortimanager", displayName: "FortiManager" },
    { name: "paloalto", displayName: "Panorama" },
    { name: "ruleblade", displayName: "Ruleblade" },
  ];

  return (
    <div className="min-h-screen bg-base-200 p-8">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold text-primary mb-8">Emulflow</h1>
        {appliances.map(({ name, displayName }) => (
          <ApplianceTest key={name} name={name} displayName={displayName} />
        ))}
      </div>
    </div>
  );
}
